const ze = globalThis.browser;
ze?.runtime?.getURL("").startsWith("moz-extension://") && (globalThis.chrome = ze);
function X() {
  return typeof chrome < "u" && !!chrome.runtime?.getURL?.("").startsWith("moz-extension://");
}
function Re() {
  return typeof navigator < "u" && /Edg\//.test(navigator.userAgent);
}
function bt() {
  return X() ? "Firefox" : (Re(), "Microsoft Edge");
}
const ue = "captureflow.popup-window.v1";
async function He() {
  return (await chrome.storage.session.get(ue))[ue];
}
async function Et(e) {
  if (e.id !== chrome.runtime.id || e.url?.split("?")[0] !== chrome.runtime.getURL("popup.html"))
    throw new Error("Untrusted window request.");
  const t = await He();
  if (t)
    try {
      const n = await chrome.windows.get(t.windowId, { populate: !0 });
      if (n.type === "popup" && n.tabs?.some((i) => i.url === chrome.runtime.getURL("popup.html?detached=1"))) {
        await chrome.windows.update(t.windowId, { focused: !0 });
        return;
      }
    } catch {
    }
  const [o] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  if (o?.windowId === void 0)
    throw new Error("Open CaptureFlow from a browser window first.");
  const r = await chrome.windows.create({
    url: chrome.runtime.getURL("popup.html?detached=1"),
    type: "popup",
    width: 420,
    height: 640,
    focused: !0
  });
  if (r?.id === void 0)
    throw new Error("The browser could not create the CaptureFlow window.");
  await chrome.storage.session.set({
    [ue]: { windowId: r.id, sourceWindowId: o.windowId }
  });
}
async function vt(e) {
  if (e < 0) return;
  const t = await He();
  if (!t || t.windowId === e) return;
  (await chrome.windows.get(e)).type === "normal" && await chrome.storage.session.set({ [ue]: { ...t, sourceWindowId: e } });
}
async function Me(e) {
  if (new URL(e.url ?? chrome.runtime.getURL("popup.html")).searchParams.get("detached") !== "1")
    return (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
  const t = await He();
  if (!t || e.tab?.windowId !== t.windowId)
    throw new Error("Reopen the CaptureFlow window from the browser toolbar.");
  let o;
  try {
    o = (await chrome.tabs.query({ active: !0, windowId: t.sourceWindowId }))[0];
  } catch {
  }
  if (!o) {
    const r = await chrome.windows.getAll({ windowTypes: ["normal"] }), n = r.find((i) => i.focused) ?? r[0];
    n?.id !== void 0 && (o = (await chrome.tabs.query({ active: !0, windowId: n.id }))[0]);
  }
  if (!o) throw new Error("Open a webpage in a browser window first.");
  return await chrome.windows.update(o.windowId, { focused: !0 }), o;
}
const St = "captureflow.window", Tt = "https://captureflow-billing.captureflow-billing.workers.dev", At = { kty: "EC", x: "ZnqEBzEbbg6uxm5fcmq6TzxLEOlOSzjTVnDQBBTx4Jk", y: "SLMq1o-4V4V9a3FordCrX5ExsjnwwP04ZJVBIt5wSgU", crv: "P-256" }, It = {
  apiOrigin: Tt,
  publicKey: At
}, b = It;
function de() {
  return /^https:\/\/[a-z0-9.-]+$/.test(b.apiOrigin) && b.publicKey?.kty === "EC";
}
const nt = [
  "authenticationInfo",
  "personallyIdentifyingInfo",
  "financialAndPaymentInfo"
];
function Ct() {
  return { origins: [b.apiOrigin + "/*"], data_collection: nt };
}
async function it() {
  return !X() || chrome.permissions.contains(Ct());
}
const kt = !0, xt = {
  enabled: kt
}, Pt = "captureflow.auth", ne = "captureflow.auth.v1", pe = "captureflow.guest.v1";
function se(e) {
  const t = e.trim();
  return t ? t.length > 254 || !/^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/.test(t) ? "Enter a valid email address, for example name@example.com." : "" : "Enter your email address.";
}
function ae(e) {
  return e.length < 6 ? "Use at least 6 characters for your password." : e.length > 128 ? "Use no more than 128 characters for your password." : /[A-Z]/.test(e) ? /[0-9]/.test(e) ? /[^\p{L}\p{N}\s]/u.test(e) ? "" : "Include at least one special character, such as !, @ or #." : "Include at least one number." : "Include at least one uppercase letter.";
}
class at extends Error {
  constructor(t, o) {
    super(o), this.status = t, this.name = "BillingHttpError";
  }
  status;
}
async function Ne(e, t, o) {
  if (!de())
    throw new Error("Automatic subscription activation is not configured yet.");
  if (X() && !await it())
    throw new Error("Allow account data access to use your account, or continue without login.");
  const r = await fetch(b.apiOrigin + e, {
    method: o ? "POST" : "GET",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + t },
    ...o ? { body: JSON.stringify(o) } : {},
    credentials: "omit",
    cache: "no-store",
    redirect: "error",
    referrerPolicy: "no-referrer",
    signal: AbortSignal.timeout(25e3)
  }), n = await r.json();
  if (!r.ok)
    throw new at(
      r.status,
      n && typeof n == "object" && "error" in n && typeof n.error == "string" ? n.error.slice(0, 240) : "Subscription service is temporarily unavailable."
    );
  return n;
}
function Te() {
  return typeof chrome < "u" && !!chrome.runtime?.id;
}
const N = "captureflow.billing.v1";
let W = null, te = { plan: "basic", paidUntil: 0 }, Ve = 0, Ye = 0;
const Ut = /* @__PURE__ */ new Set(), Ae = (e) => Uint8Array.from(atob(e.replaceAll("-", "+").replaceAll("_", "/")), (t) => t.charCodeAt(0)), ct = (e) => btoa(String.fromCharCode(...e)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
async function Lt(e) {
  return ct(
    new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e)))
  );
}
async function he(e, t, o, r, n = Date.now()) {
  if (e.length > 4096 || !/^[A-Za-z0-9_-]{43}$/.test(t))
    throw new Error("Invalid license data.");
  const i = e.split(".");
  if (i.length !== 3 || i.some((f) => !/^[A-Za-z0-9_-]+$/.test(f)))
    throw new Error("Invalid license signature.");
  const [a, c, s] = i, d = JSON.parse(new TextDecoder().decode(Ae(a)));
  if (d.alg !== "ES256" || d.typ !== "JWT")
    throw new Error("Unsupported license signature.");
  const l = await crypto.subtle.importKey(
    "jwk",
    r,
    { name: "ECDSA", namedCurve: "P-256" },
    !1,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    l,
    Ae(s),
    new TextEncoder().encode(a + "." + c)
  ))
    throw new Error("License signature verification failed.");
  const u = JSON.parse(new TextDecoder().decode(Ae(c))), h = Math.floor(n / 1e3);
  if (u.iss !== o || u.aud !== "captureflow" || u.sub !== await Lt(t) || !["basic", "pro"].includes(u.plan) || !Number.isSafeInteger(u.iat) || !Number.isSafeInteger(u.exp) || !Number.isSafeInteger(u.paidUntil) || u.paidUntil < 0 || u.iat > h + 300 || u.exp <= h || u.exp <= u.iat || u.exp - u.iat > 21600 || (u.source === "admin" ? u.plan !== "pro" || u.paidUntil !== 0 || u.exp - u.iat > 600 : u.plan === "pro" && (u.paidUntil <= n || u.exp * 1e3 > u.paidUntil)))
    throw new Error("This license has expired or belongs to another installation.");
  return u;
}
function st() {
  const e = Ve = Math.max(Ve, Date.now()), t = W?.plan === "pro" && W.exp * 1e3 > e && (W.source === "admin" || W.paidUntil > e) ? "pro" : "basic", o = W?.paidUntil ?? 0;
  if (te.plan !== t || te.paidUntil !== o) {
    te = { plan: t, paidUntil: o };
    for (const r of Ut) r();
  }
}
function lt() {
  return st(), te.plan;
}
function Rt() {
  return te;
}
async function we() {
  if (!Te()) return null;
  if (!chrome.storage?.local) {
    const t = await chrome.runtime.sendMessage({
      channel: "captureflow.billing",
      type: "CACHED"
    });
    return t?.ok ? t.data : null;
  }
  const e = (await chrome.storage.local.get(N))[N];
  return !e || typeof e.recoveryKey != "string" || !/^[A-Za-z0-9_-]{43}$/.test(e.recoveryKey) ? null : {
    recoveryKey: e.recoveryKey,
    entitlement: typeof e.entitlement == "string" ? e.entitlement : "",
    checkedAt: typeof e.checkedAt == "number" ? e.checkedAt : 0,
    checkoutPending: e.checkoutPending === !0
  };
}
async function I() {
  if (!de()) return;
  const e = ++Ye;
  let t = null;
  try {
    const o = await we();
    o?.entitlement && b.publicKey && (t = await he(
      o.entitlement,
      o.recoveryKey,
      b.apiOrigin,
      b.publicKey
    ));
  } catch {
  }
  Ye === e && (W = t, st());
}
async function V(e) {
  await chrome.storage.local.remove(ne), await chrome.storage.local.remove(N), await chrome.storage.local.set({ [pe]: e }), await I();
}
async function _(...e) {
  try {
    return await Ne(...e);
  } catch (t) {
    const o = e[2]?.operation;
    throw t instanceof at && t.status === 401 && o !== "login" && o !== "register" && await V(!1), t;
  }
}
async function Y() {
  const e = (await chrome.storage.local.get(ne))[ne];
  return !e || typeof e.idToken != "string" || typeof e.refreshToken != "string" || typeof e.uid != "string" || typeof e.email != "string" || typeof e.expiresAt != "number" ? null : e;
}
async function ut(e) {
  if (!e.idToken || !e.refreshToken || !e.uid || !Number.isFinite(e.expiresAt) || se(e.email))
    throw new Error("The account service returned an invalid session. Please log in again.");
  await chrome.storage.local.set({ [ne]: e, [pe]: !1 });
}
async function Z(e, t = !1) {
  if (!e.emailVerified) return;
  const o = await we(), r = await _("/v1/account", e.idToken, {
    previousKey: o?.recoveryKey ?? ""
  });
  if (!b.publicKey) throw new Error("Subscription verification is not configured.");
  if (t) {
    o?.recoveryKey !== r.recoveryKey && await chrome.storage.local.set({
      [N]: {
        recoveryKey: r.recoveryKey,
        entitlement: "",
        checkedAt: 0
      }
    }), await I();
    return;
  }
  const n = await _("/v1/license", r.recoveryKey);
  if (!b.publicKey) throw new Error("Subscription verification is not configured.");
  await he(
    n.entitlement,
    r.recoveryKey,
    b.apiOrigin,
    b.publicKey
  ), await chrome.storage.local.set({
    [N]: {
      recoveryKey: r.recoveryKey,
      entitlement: n.entitlement,
      checkedAt: Date.now(),
      checkoutPending: o?.recoveryKey === r.recoveryKey && o.checkoutPending === !0
    }
  }), await I();
}
async function G(e = !1) {
  let t = await Y();
  return t ? ((e || t.expiresAt < Date.now() + 6e4) && (t = await _("/v1/auth", "", {
    operation: "refresh",
    refreshToken: t.refreshToken
  }), await ut(t)), t) : null;
}
async function Mt() {
  const e = await G(!0);
  if (!e) throw new Error("Log in to your CaptureFlow account before subscribing to Pro.");
  if (!e.emailVerified)
    throw new Error("Confirm your email first. Open Login to resend the verification email.");
  return await Z(e, !0), e.idToken;
}
async function qe(e, t) {
  const o = t.url?.split("?")[0];
  if (t.id !== chrome.runtime.id || !["popup.html"].some((a) => o === chrome.runtime.getURL(a)))
    throw new Error("Untrusted account request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid account request.");
  const r = e;
  if (r.type === "STATUS" && X() && !await it() && await Y() && await V(!1), r.type === "LOGOUT" || r.type === "GUEST")
    await V(r.type === "GUEST");
  else if (r.type !== "STATUS")
    if (["LOGIN", "REGISTER", "RESET"].includes(String(r.type))) {
      const a = typeof r.email == "string" ? r.email.trim() : "";
      if (se(a)) throw new Error(se(a));
      if (r.type === "REGISTER" && ae(typeof r.password == "string" ? r.password : ""))
        throw new Error(ae(typeof r.password == "string" ? r.password : ""));
      if (r.type !== "RESET" && (typeof r.password != "string" || !r.password || r.password.length > 128))
        throw new Error("Enter your password.");
      if (r.type === "RESET")
        await _("/v1/auth", "", { operation: "reset", email: a }), await V(!1);
      else {
        const c = await _(
          "/v1/auth",
          "",
          {
            operation: r.type === "LOGIN" ? "login" : "register",
            ...r.type === "REGISTER" ? { sendVerification: "true" } : {},
            email: a,
            password: r.password
          }
        ), s = await Y();
        if (s && s.uid !== c.uid && (await chrome.storage.local.remove(N), await I()), r.type === "REGISTER") {
          if (await V(!1), c.verificationEmailSent !== !0)
            throw new Error(
              c.emailVerified ? "Your email is already verified. Log in to continue." : "Your account was created, but email sending was not confirmed. Log in and use Resend verification email."
            );
        } else
          await ut(c), await Z(c);
      }
    } else if (r.type === "RESET_FINISH") {
      if (typeof r.email != "string" || se(r.email))
        throw new Error("Enter a valid email address.");
      if (typeof r.password != "string" || ae(r.password))
        throw new Error(ae(typeof r.password == "string" ? r.password : ""));
      await _("/v1/auth", "", {
        operation: "resetFinish",
        email: r.email.trim(),
        password: r.password,
        link: typeof r.link == "string" ? r.link : ""
      }), (await Y())?.email.toLowerCase() === r.email.trim().toLowerCase() && (await chrome.storage.local.remove(ne), await chrome.storage.local.remove(N), await I());
    } else if (r.type === "VERIFY_FINISH") {
      const a = await G();
      if (!a) throw new Error("Please log in again.");
      await _("/v1/auth", "", {
        operation: "verifyFinish",
        idToken: a.idToken,
        link: typeof r.link == "string" ? r.link : ""
      });
      const c = await G(!0);
      c && await Z(c);
    } else if (r.type === "RESUME") {
      const a = await G(!0);
      a && await Z(a);
    } else if (r.type === "VERIFY") {
      const a = await G();
      if (!a) throw new Error("Please log in again.");
      const c = await _("/v1/auth", "", { operation: "verify", idToken: a.idToken });
      if (c.alreadyVerified) {
        const s = await G(!0);
        s && await Z(s);
      } else if (c.sent !== !0 || c.email?.trim().toLowerCase() !== a.email.trim().toLowerCase())
        throw new Error("The email service did not confirm sending. Please try again.");
    } else throw new Error("Unknown account command.");
  const n = await Y(), i = (await chrome.storage.local.get(pe))[pe] === !0;
  return {
    configured: xt.enabled,
    guest: i,
    user: n ? { email: n.email, emailVerified: n.emailVerified } : null
  };
}
const Nt = "captureflow.billing";
async function Ft(e, t) {
  if (t.id !== chrome.runtime.id || !t.url?.startsWith(chrome.runtime.getURL("")) || t.tab && !["popup.html", "capture.html", "history.html", "recording.html"].some(
    (s) => t.url.split("?")[0] === chrome.runtime.getURL(s)
  ))
    throw new Error("Untrusted billing request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid billing command.");
  const o = e;
  let r = await we();
  const i = (await Y())?.emailVerified === !0, a = () => ({
    configured: de(),
    plan: lt(),
    paidUntil: Rt().paidUntil,
    recoveryKey: i ? r?.recoveryKey ?? "" : "",
    checkedAt: r?.checkedAt ?? 0,
    checkoutPending: i && r?.checkoutPending === !0
  });
  if (await I(), o.type === "STATUS") return a();
  if (o.type === "CACHED") return r;
  if (o.type === "REFRESH" && !i) return a();
  if (!de() || !b.publicKey)
    throw new Error("Automatic subscription activation is not configured yet.");
  const c = async (s) => {
    await chrome.storage.local.set({ [N]: s }), r = s, await I();
  };
  if (o.type === "REFRESH" && r && r.checkedAt > Date.now() - 1e4)
    try {
      return await he(
        r.entitlement,
        r.recoveryKey,
        b.apiOrigin,
        b.publicKey
      ), a();
    } catch {
    }
  if (o.type === "REFRESH" || o.type === "RESTORE") {
    const s = o.type === "RESTORE" && typeof o.key == "string" ? o.key.trim().replace(/^CF-/, "") : r?.recoveryKey;
    if (!s || !/^[A-Za-z0-9_-]{43}$/.test(s))
      throw new Error("Enter a valid CaptureFlow recovery key.");
    const d = await Ne(
      "/v1/license",
      s
    ), l = await he(
      d.entitlement,
      s,
      b.apiOrigin,
      b.publicKey
    );
    return await c({
      recoveryKey: s,
      entitlement: d.entitlement,
      checkedAt: Date.now(),
      checkoutPending: l.plan !== "pro" && o.type === "REFRESH" && r?.checkoutPending === !0
    }), { ...a(), verificationPending: d.verificationPending === !0 };
  }
  if (o.type === "CHECKOUT") {
    const s = await Mt();
    if (r = await we(), o.plan !== "monthly" && o.plan !== "yearly")
      throw new Error("Choose a monthly or yearly plan.");
    r || await c({
      recoveryKey: ct(crypto.getRandomValues(new Uint8Array(32))),
      entitlement: "",
      checkedAt: 0
    });
    const d = r.recoveryKey, l = await Ne("/v1/checkout", d, {
      plan: o.plan,
      ...s ? { idToken: s } : {}
    }), u = new URL(l.url);
    if (u.protocol !== "https:" || !["www.paypal.com", "www.sandbox.paypal.com"].includes(u.hostname) || u.username || u.password || u.port)
      throw new Error("Unexpected PayPal checkout address.");
    return await c({ ...r, checkoutPending: !0, checkedAt: 0 }), await chrome.tabs.create({ url: u.href }), a();
  }
  if (o.type === "FORGET")
    return await chrome.storage.local.remove(N), r = null, await I(), a();
  throw new Error("Unknown billing command.");
}
const _t = "captureflow/history/v1";
function Ot(e) {
  const t = e && typeof e == "object" ? e : null, o = typeof t?.message == "string" ? t.message : "Local history is unavailable. Try again.";
  return t?.name === "QuotaExceededError" || /quota/i.test(o) ? "Local history storage is full. Download this capture, delete unneeded history or free disk space, then try Save to history again." : o;
}
const Fe = {
  basic: {
    label: "Basic",
    screenshots: 100,
    videos: 10,
    maxVideoMs: 3e5,
    editor: !1,
    adjustableQuality: !1,
    imageWidth: 1920
  },
  pro: {
    label: "Pro",
    screenshots: 1 / 0,
    videos: 1 / 0,
    maxVideoMs: 1 / 0,
    editor: !0,
    adjustableQuality: !0,
    imageWidth: 1 / 0
  }
};
function dt() {
  return lt();
}
function Ie(e, t = dt()) {
  return Fe[t].adjustableQuality ? { ...e } : { ...e, quality: "standard" };
}
const re = "captureflow.usage.v1";
function Dt(e = /* @__PURE__ */ new Date()) {
  return e.toISOString().slice(0, 7);
}
function Qe(e, t = /* @__PURE__ */ new Date()) {
  const o = Dt(t), r = e && typeof e == "object" ? e : {}, n = typeof r.month == "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(r.month) ? r.month : "";
  if (n < o) return { month: o, screenshots: [], videos: [] };
  const i = (a) => Array.isArray(r[a]) ? [
    ...new Set(
      r[a].filter(
        (c) => typeof c == "string" && c.length > 0
      )
    )
  ] : [];
  return { month: n, screenshots: i("screenshots"), videos: i("videos") };
}
async function fe(e = /* @__PURE__ */ new Date()) {
  try {
    if (Te())
      return Qe((await chrome.storage.local.get(re))[re], e);
    const t = localStorage.getItem(re);
    return Qe(t ? JSON.parse(t) : null, e);
  } catch {
    throw new Error("Monthly usage could not be read. Reopen CaptureFlow and try again.");
  }
}
function me(e, t, o, r = dt()) {
  const n = t === "screenshot" ? e.screenshots : e.videos;
  if (o && n.includes(o)) return;
  const i = t === "screenshot" ? Fe[r].screenshots : Fe[r].videos;
  if (n.length >= i)
    throw new Error(
      "Basic monthly limit reached: " + i + (t === "screenshot" ? " screenshots" : " videos") + ". Limits reset on the first day of each month (UTC)."
    );
}
async function pt(e, t, o = /* @__PURE__ */ new Date()) {
  if (!t) throw new Error("Missing capture identifier.");
  const r = await fe(o);
  me(r, e, t);
  const n = e === "screenshot" ? r.screenshots : r.videos;
  if (n.includes(t)) return r;
  n.push(t);
  try {
    Te() ? await chrome.storage.local.set({ [re]: r }) : localStorage.setItem(re, JSON.stringify(r));
  } catch {
    throw new Error("Monthly usage could not be saved. Check available browser storage.");
  }
  return r;
}
async function Xe(e, t = !0) {
  if (e.controlsWindowId != null)
    try {
      return await chrome.windows.update(
        e.controlsWindowId,
        t ? { focused: !0, state: "normal", width: 280, height: 106 } : { width: 280, height: 106 }
      ), e;
    } catch {
    }
  const o = await chrome.windows.create({
    url: chrome.runtime.getURL("controls.html?id=" + encodeURIComponent(e.id)),
    type: "popup",
    width: 280,
    height: 106,
    focused: t
  });
  if (o?.id === void 0)
    throw new Error(
      "Microsoft Edge could not open recording controls. Use the extension popup to control this recording."
    );
  return {
    ...e,
    controlsWindowId: o.id,
    controlsTabId: o.tabs?.[0]?.id ?? null,
    controlsOpened: !0,
    controlsError: ""
  };
}
async function Ce(e) {
  if (e.controlsWindowId != null)
    try {
      await chrome.windows.remove(e.controlsWindowId);
    } catch {
    }
}
const M = Object.freeze({
  schemaVersion: 1,
  theme: "dark",
  screenshotFormat: "png",
  jpegQuality: 90,
  filename: "CaptureFlow",
  recordingMode: "tab",
  recordingQuality: "high",
  microphone: !1,
  autoSave: !0
});
function Je(e) {
  const t = typeof e == "object" && e !== null ? e : {}, o = (n, i, a) => i.includes(n) ? n : a, r = typeof t.filename == "string" ? t.filename.trim().replace(/[<>:"/\\|?*\u0000-\u001f]/g, "").slice(0, 80) : "";
  return {
    schemaVersion: 1,
    theme: o(t.theme, ["dark", "light", "system"], M.theme),
    screenshotFormat: o(
      t.screenshotFormat,
      ["png", "jpeg"],
      M.screenshotFormat
    ),
    jpegQuality: typeof t.jpegQuality == "number" && Number.isFinite(t.jpegQuality) ? Math.max(10, Math.min(100, Math.round(t.jpegQuality))) : M.jpegQuality,
    filename: r || M.filename,
    recordingMode: o(
      t.recordingMode,
      ["tab", "window", "screen"],
      M.recordingMode
    ),
    recordingQuality: o(
      t.recordingQuality,
      ["standard", "high", "maximum"],
      M.recordingQuality
    ),
    // Retained for older stored records; voice capture is disabled.
    microphone: !1,
    autoSave: typeof t.autoSave == "boolean" ? t.autoSave : M.autoSave
  };
}
const ke = "captureflow.settings.v1";
async function $e() {
  if (Te()) {
    const t = await chrome.storage.local.get(ke);
    return Je(t[ke]);
  }
  const e = localStorage.getItem(ke);
  try {
    return Je(e ? JSON.parse(e) : M);
  } catch {
    return { ...M };
  }
}
const Ht = "captureflow.recordings.v1", jt = 2;
function Kt() {
  return new Promise((e, t) => {
    let o = !1;
    const r = indexedDB.open(Ht, jt);
    r.onupgradeneeded = () => {
      const n = r.result;
      n.objectStoreNames.contains("recordings") || n.createObjectStore("recordings", { keyPath: "id" }), n.objectStoreNames.contains("chunks") || n.createObjectStore("chunks", { keyPath: ["id", "index"] }).createIndex("recording", "id"), n.objectStoreNames.contains("screenshots") || n.createObjectStore("screenshots", { keyPath: "id" }), n.objectStoreNames.contains("assets") || n.createObjectStore("assets", { keyPath: ["id", "kind"] }).createIndex("capture", "id");
    }, r.onerror = () => t(r.error ?? new Error("Local capture storage is unavailable.")), r.onblocked = () => {
      o = !0, t(new Error("Close other CaptureFlow pages and retry the history upgrade."));
    }, r.onsuccess = () => {
      const n = r.result;
      if (o) {
        n.close();
        return;
      }
      n.onversionchange = () => n.close(), e(n);
    };
  });
}
async function C(e, t, o) {
  const r = await Kt();
  try {
    return await new Promise((n, i) => {
      const a = r.transaction(e, t);
      let c, s = null;
      a.oncomplete = () => n(c), a.onabort = () => i(s ?? a.error ?? new Error("Local capture storage transaction failed.")), a.onerror = () => {
      };
      const d = (l) => {
        s = l, a.abort();
      };
      try {
        o(
          a,
          (l) => {
            c = l;
          },
          d
        );
      } catch (l) {
        s = l instanceof Error ? l : new Error("Local history operation failed."), a.abort();
      }
    });
  } finally {
    r.close();
  }
}
function ge(e, t) {
  const o = e.objectStore("assets").index("capture").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("assets").delete(r.primaryKey), r.continue());
  };
}
function je(e, t) {
  const o = e.objectStore("chunks").index("recording").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("chunks").delete(r.primaryKey), r.continue());
  };
}
async function Bt(e) {
  await C(["recordings"], "readwrite", (t) => {
    t.objectStore("recordings").put(e);
  });
}
async function ye(e) {
  return C(["recordings"], "readonly", (t, o) => {
    const r = t.objectStore("recordings").get(e);
    r.onsuccess = () => o(r.result ?? null);
  });
}
async function Wt() {
  return C(["recordings"], "readonly", (e, t) => {
    const o = e.objectStore("recordings").getAll();
    o.onsuccess = () => t(o.result.sort((r, n) => n.createdAt - r.createdAt));
  });
}
async function Gt(e, t) {
  return C(["chunks"], "readonly", (o, r) => {
    const n = o.objectStore("chunks").index("recording").getAll(IDBKeyRange.only(e));
    n.onsuccess = () => {
      const i = n.result;
      if (i.sort((a, c) => a.index - c.index), !i.length) {
        r(new Blob([], { type: t }));
        return;
      }
      r(
        new Blob(
          i.map((a) => a.blob),
          { type: t }
        )
      );
    };
  });
}
async function zt(e) {
  return C(["recordings"], "readwrite", (t, o, r) => {
    const n = t.objectStore("recordings"), i = n.get(e);
    i.onsuccess = () => {
      const a = i.result;
      if (!a) {
        r(new Error("This temporary recording has already been removed."));
        return;
      }
      const c = { ...a, retention: "saved" };
      n.put(c), o(c);
    };
  });
}
async function Vt(e, t) {
  await C(["recordings"], "readwrite", (o) => {
    const r = o.objectStore("recordings"), n = r.get(e);
    n.onsuccess = () => {
      const i = n.result;
      i?.retention === "temporary" && r.put({ ...i, previewTabId: t });
    };
  });
}
async function Yt(e) {
  return C(["recordings", "chunks", "assets"], "readwrite", (t, o) => {
    let r = 0;
    const n = t.objectStore("recordings").openCursor();
    n.onsuccess = () => {
      const i = n.result;
      if (!i) {
        o(r);
        return;
      }
      const a = i.value;
      a.retention === "temporary" && !e.has(a.id) && (i.delete(), je(t, a.id), ge(t, a.id), r++), i.continue();
    };
  });
}
const Ze = "captureflow.history.changed";
function le() {
  typeof window < "u" && window.dispatchEvent(new Event(Ze));
  try {
    if (typeof BroadcastChannel == "function") {
      const e = new BroadcastChannel(Ze);
      e.postMessage("changed"), e.close();
    }
  } catch {
  }
}
const qt = "captureflow/recording/v1", Qt = "captureflow/recording-host/v1", _e = "captureflow.recording.v1", A = (e) => !!e && ["setup", "starting", "recording", "paused", "stopping"].includes(e.status);
function Xt(e, t = Date.now()) {
  return Math.max(
    0,
    e.elapsedMs + (e.clockStartedAt === null ? 0 : Math.max(0, t - e.clockStartedAt))
  );
}
function xe(e) {
  if (!e || typeof e != "object") throw new Error("Invalid recording options.");
  const t = e;
  if (!["tab", "window", "screen"].includes(String(t.mode)) || !["standard", "high", "maximum"].includes(String(t.quality)) || typeof t.microphone != "boolean" || typeof t.audio != "boolean")
    throw new Error("Invalid recording options.");
  return {
    mode: t.mode,
    quality: t.quality,
    microphone: !1,
    audio: t.audio
  };
}
const et = 32760, Jt = 64e6;
function be(e, t) {
  if (![e, t].every(Number.isSafeInteger) || e < 1 || t < 1)
    throw new Error("The screenshot has invalid dimensions.");
  if (e > et || t > et || e * t > Jt)
    throw new Error(
      "This page exceeds the safe screenshot size (32,760 pixels per side or 64 megapixels). Try a selected area or reduce browser zoom."
    );
}
function oe(e) {
  let t;
  try {
    t = new URL(e);
  } catch {
    throw new Error("Open a normal website before capturing.");
  }
  if (!["http:", "https:"].includes(t.protocol) || t.hostname === "chromewebstore.google.com" || Re() && t.hostname === "microsoftedge.microsoft.com" && t.pathname.startsWith("/addons") || Re() && t.hostname === "edge.microsoft.com" && t.pathname.startsWith("/addons") || X() && ["addons.mozilla.org", "accounts.firefox.com", "support.mozilla.org"].includes(
    t.hostname
  ) || t.hostname === "chrome.google.com" && t.pathname.startsWith("/webstore"))
    throw new Error(
      bt() + " protects this page. Open an ordinary HTTP or HTTPS webpage to capture it."
    );
  if (t.hostname === "chromewebstore.google.com")
    throw new Error("Microsoft Edge Add-ons pages cannot be captured by CaptureFlow.");
}
function Ke(e) {
  if (!e || ![
    e.width,
    e.height,
    e.documentWidth,
    e.documentHeight,
    e.scrollX,
    e.scrollY,
    e.dpr,
    e.visualScale
  ].every(Number.isFinite) || e.width <= 0 || e.height <= 0 || e.dpr <= 0)
    throw new Error("The page returned invalid viewport dimensions.");
  if (Math.abs(e.visualScale - 1) > 0.01)
    throw new Error("Reset pinch zoom before capturing this page. Browser zoom is supported.");
}
function ht(e, t, o, r) {
  if (Ke(t), !e || ![e.x, e.y, e.width, e.height].every(Number.isFinite) || e.width < 2 || e.height < 2 || e.x < 0 || e.y < 0 || e.x + e.width > t.width + 0.5 || e.y + e.height > t.height + 0.5)
    throw new Error("Select a valid area at least 2 × 2 pixels inside the viewport.");
  const n = o / t.width, i = r / t.height, a = Math.max(0, Math.round(e.x * n)), c = Math.max(0, Math.round(e.y * i)), s = Math.min(o, Math.round((e.x + e.width) * n)), d = Math.min(r, Math.round((e.y + e.height) * i)), l = { x: a, y: c, width: s - a, height: d - c };
  return be(l.width, l.height), l;
}
function tt(e, t) {
  return Math.abs(e.width - t.width) < 0.5 && Math.abs(e.height - t.height) < 0.5 && Math.abs(e.dpr - t.dpr) < 1e-3 && Math.abs(e.scrollX - t.scrollX) < 1 && Math.abs(e.scrollY - t.scrollY) < 1;
}
async function $t(e, t = !1) {
  const o = window;
  if (t) {
    o.__captureFlowFullSnapshot?.id === e && o.__captureFlowFullSnapshot.cleanup();
    return;
  }
  if (Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight ?? 0) <= innerHeight + 2 && Array.from(document.querySelectorAll("body *")).some((l) => {
    const u = l.getBoundingClientRect();
    return /auto|scroll/.test(getComputedStyle(l).overflowY) && l.scrollHeight > l.clientHeight + 50 && u.width * u.height > innerWidth * innerHeight * 0.5;
  }))
    throw new Error(
      "Nested scrolling pages are not supported. Use a visible or selected-area capture."
    );
  if (o.__captureFlowFullSnapshot)
    throw new Error("A full-page snapshot is already preparing this page.");
  const r = Array.from(document.images).filter((l) => l.loading === "lazy"), n = r.map((l) => ({ image: l, value: l.getAttribute("loading") })), i = document.createElement("style");
  i.textContent = "*,*::before,*::after{animation-play-state:paused!important;transition:none!important;overflow-anchor:none!important;}", document.documentElement.append(i);
  const a = Array.from(document.querySelectorAll("body *")).filter((l) => getComputedStyle(l).contentVisibility === "auto").map((l) => ({
    element: l,
    value: l.style.getPropertyValue("content-visibility"),
    priority: l.style.getPropertyPriority("content-visibility")
  }));
  for (const { element: l } of a)
    l.style.setProperty("content-visibility", "visible", "important");
  let c;
  const s = () => {
    clearTimeout(c), i.remove();
    for (const { element: l, value: u, priority: h } of a)
      u ? l.style.setProperty("content-visibility", u, h) : l.style.removeProperty("content-visibility");
    for (const { image: l, value: u } of n)
      u === null ? l.removeAttribute("loading") : l.setAttribute("loading", u);
    o.__captureFlowFullSnapshot?.id === e && delete o.__captureFlowFullSnapshot;
  };
  o.__captureFlowFullSnapshot = { id: e, cleanup: s }, c = setTimeout(s, 3e4);
  for (const l of r) l.loading = "eager";
  let d;
  try {
    await Promise.race([
      Promise.all(
        Array.from(document.images).map(
          (l) => l.complete ? Promise.resolve() : l.decode().catch(() => {
          })
        )
      ),
      new Promise((l) => {
        d = setTimeout(l, 1500);
      })
    ]);
  } finally {
    clearTimeout(d);
  }
}
async function Be(e, t) {
  try {
    const o = globalThis.browser ?? globalThis.chrome, r = window, n = () => new Promise((d, l) => {
      const u = setTimeout(
        () => l(
          new Error(
            "The source page stopped rendering. Keep its tab and window visible, then retry."
          )
        ),
        1e3
      );
      requestAnimationFrame(
        () => requestAnimationFrame(() => {
          clearTimeout(u), d();
        })
      );
    }), i = () => {
      if (!["text/html", "application/xhtml+xml"].includes(document.contentType))
        throw new Error("This document type is not supported. Open an HTML webpage.");
      const d = document.documentElement, l = document.body;
      return {
        width: innerWidth,
        height: innerHeight,
        documentWidth: Math.max(d.scrollWidth, l?.scrollWidth ?? 0),
        documentHeight: Math.max(d.scrollHeight, l?.scrollHeight ?? 0, innerHeight),
        scrollX,
        scrollY,
        dpr: devicePixelRatio,
        visualScale: visualViewport?.scale ?? 1
      };
    }, a = async () => {
      await n();
      const d = Array.from(document.images).filter((u) => {
        const h = u.getBoundingClientRect();
        return h.bottom > 0 && h.top < innerHeight && !u.complete;
      });
      let l;
      try {
        await Promise.race([
          Promise.all(d.map((u) => u.decode().catch(() => {
          }))),
          new Promise((u) => {
            l = setTimeout(u, 1e3);
          })
        ]);
      } finally {
        clearTimeout(l);
      }
      await n();
    };
    if (e.action === "restore")
      return r.__captureFlowPage?.id === t && r.__captureFlowPage.cleanup(), r.__captureFlowSelection?.id === t && r.__captureFlowSelection.cleanup(), await n(), { ok: !0, value: i() };
    if (e.action === "inspect") return { ok: !0, value: i() };
    if (e.action === "prepare") {
      if (r.__captureFlowPage) throw new Error("A capture is already preparing this page.");
      const d = i();
      if (d.documentWidth > d.width + 2)
        throw new Error(
          "Full-page capture currently supports vertical pages. Use a selected area for horizontally scrolling pages."
        );
      if (d.documentHeight <= d.height + 2 && Array.from(document.querySelectorAll("body *")).some((P) => {
        const K = P.getBoundingClientRect(), yt = getComputedStyle(P);
        return /auto|scroll/.test(yt.overflowY) && P.scrollHeight > P.clientHeight + 50 && K.width * K.height > innerWidth * innerHeight * 0.5;
      }))
        throw new Error(
          "This page scrolls inside a container. Use Visible area or Selected area."
        );
      const l = new CSSStyleSheet();
      l.replaceSync(
        "html,body,*{scroll-behavior:auto!important;scroll-snap-type:none!important;overflow-anchor:none!important;animation-play-state:paused!important;transition:none!important;caret-color:transparent!important}*::-webkit-scrollbar{display:none!important}"
      ), document.adoptedStyleSheets = [...document.adoptedStyleSheets, l];
      const u = document.createElement("div");
      u.style.cssText = "position:fixed!important;right:20px!important;bottom:20px!important;z-index:2147483647!important;display:block!important;";
      const h = u.attachShadow({ mode: "closed" }), f = new CSSStyleSheet();
      f.replaceSync(
        ":host{all:initial}div{font:13px Segoe UI,sans-serif;background:#191c22;color:#eff1f5;border:1px solid #b6a2ff;border-radius:12px;padding:14px;box-shadow:0 8px 30px #0005}button{background:#b6a2ff;border:0;border-radius:6px;padding:6px 10px;margin-left:12px;cursor:pointer;color:#191c22}"
      ), h.adoptedStyleSheets = [f];
      const E = document.createElement("span");
      E.textContent = "CaptureFlow · preparing…";
      const m = document.createElement("div"), k = document.createElement("button");
      k.textContent = "Cancel", m.append(E, k), h.append(m), document.documentElement.append(u);
      const L = /* @__PURE__ */ new Map(), x = Array.from(document.querySelectorAll("video")).filter(
        (w) => !w.paused
      );
      x.forEach((w) => w.pause());
      let S;
      const R = (w) => {
        p(), o.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: t,
          ...w ? { error: w } : {}
        }).catch(() => {
        });
      }, T = (w) => w.preventDefault(), F = (w) => {
        w.key === "Escape" ? (w.preventDefault(), R()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(w.key) && w.preventDefault();
      }, p = () => {
        clearTimeout(S), u.remove(), document.adoptedStyleSheets = document.adoptedStyleSheets.filter((w) => w !== l), L.forEach((w, P) => {
          w.value ? P.style.setProperty("visibility", w.value, w.priority) : P.style.removeProperty("visibility");
        }), window.removeEventListener("wheel", T, !0), window.removeEventListener("touchmove", T, !0), window.removeEventListener("keydown", F, !0), window.scrollTo({ left: d.scrollX, top: d.scrollY, behavior: "instant" }), x.forEach((w) => {
          w.play().catch(() => {
          });
        }), r.__captureFlowPage?.id === t && delete r.__captureFlowPage;
      }, g = () => {
        clearTimeout(S), S = setTimeout(
          () => R("Capture stopped responding. The original page has been restored."),
          2e4
        );
      };
      r.__captureFlowPage = { id: t, cleanup: p, touch: g, hidden: L, hud: u, label: E, anchors: [] }, k.addEventListener("click", () => R()), window.addEventListener("wheel", T, { capture: !0, passive: !1 }), window.addEventListener("touchmove", T, { capture: !0, passive: !1 }), window.addEventListener("keydown", F, !0), g(), window.scrollTo({ left: 0, top: 0, behavior: "instant" });
      try {
        return await a(), await n(), { ok: !0, value: i() };
      } catch (w) {
        throw p(), w;
      }
    }
    if (e.action === "hideHud" || e.action === "showHud") {
      const d = r.__captureFlowPage;
      if (d?.id === t) {
        if (d.touch(), e.action === "showHud") {
          const l = /* @__PURE__ */ new Set();
          if (typeof document.elementsFromPoint == "function")
            for (const u of [innerWidth * 0.2, innerWidth * 0.5, innerWidth * 0.8])
              for (const h of [innerHeight * 0.25, innerHeight * 0.55, innerHeight * 0.85]) {
                const f = document.elementsFromPoint(u, h).find(
                  (m) => m !== d.hud && m !== document.documentElement && m !== document.body
                );
                if (!f) continue;
                let E = !1;
                for (let m = f; m; m = m.parentElement)
                  if (["fixed", "sticky"].includes(getComputedStyle(m).position)) {
                    E = !0;
                    break;
                  }
                E || l.add(f);
              }
          d.anchors = [...l].map((u) => {
            const h = u.getBoundingClientRect();
            return { element: u, top: h.top + scrollY, height: h.height };
          });
        }
        d.hud.style.setProperty(
          "display",
          e.action === "hideHud" ? "none" : "block",
          "important"
        ), e.action === "hideHud" && await n();
      }
      return { ok: !0, value: i() };
    }
    if (e.action !== "step") throw new Error("Unsupported page action.");
    const c = r.__captureFlowPage;
    if (!c || c.id !== t)
      throw new Error("The page capture expired. Please try again.");
    const s = () => {
      for (const d of c.anchors) {
        const l = d.element.getBoundingClientRect();
        if (!d.element.isConnected || Math.abs(l.top + scrollY - d.top) > 1 || Math.abs(l.height - d.height) > 1)
          throw new Error(
            "Content already captured shifted while loading. Wait for the page to stabilize, then retry."
          );
      }
    };
    return s(), c.touch(), c.label.textContent = "CaptureFlow · " + Math.round(e.progress) + "%", c.hud.style.setProperty("display", "block", "important"), e.hideSticky && Array.from(document.querySelectorAll("body *")).forEach((d) => {
      const l = getComputedStyle(d).position;
      (l === "fixed" || l === "sticky") && !c.hidden.has(d) && (c.hidden.set(d, {
        value: d.style.getPropertyValue("visibility"),
        priority: d.style.getPropertyPriority("visibility")
      }), d.style.setProperty("visibility", "hidden", "important"));
    }), window.scrollTo({ left: 0, top: e.y, behavior: "instant" }), await a(), s(), await n(), { ok: !0, value: i() };
  } catch (o) {
    return {
      ok: !1,
      error: o instanceof Error ? o.message : "The page could not be prepared."
    };
  }
}
function Zt(e) {
  if (typeof e != "string" || !e)
    throw new Error("Microsoft Edge returned an empty full-page image.");
  const t = Uint8Array.from(atob(e.slice(0, 44)), (i) => i.charCodeAt(0));
  if (t.length < 24 || ![137, 80, 78, 71, 13, 10, 26, 10].every((i, a) => t[a] === i))
    throw new Error("Microsoft Edge returned an invalid full-page PNG.");
  const o = new DataView(t.buffer), r = o.getUint32(16), n = o.getUint32(20);
  return be(r, n), { width: r, height: n, data: e };
}
async function er(e) {
  const t = { tabId: e.sourceTabId };
  let o = !1;
  const r = (i = !1) => chrome.scripting.executeScript({
    target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
    func: $t,
    args: [e.id, i]
  }), n = async () => {
    const a = (await chrome.scripting.executeScript({
      target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
      func: Be,
      args: [{ action: "inspect" }, e.id]
    }))[0]?.result;
    if (!a?.ok) throw new Error(a && !a.ok ? a.error : "The page is unavailable.");
    return a.value;
  };
  try {
    await chrome.debugger.attach(t, "1.3"), o = !0, await r();
    const i = await n(), a = async () => (await chrome.debugger.sendCommand(t, "Page.getLayoutMetrics")).cssContentSize, c = (l, u) => !!u && ["x", "y", "width", "height"].every(
      (h) => Math.abs(l[h] - u[h]) <= 1
    );
    let s = await a();
    const d = Date.now();
    for (let l = 0; l < 3; l++) {
      if (!s || ![s.x, s.y, s.width, s.height].every(Number.isFinite) || s.width < 1 || s.height < 1)
        throw new Error("Microsoft Edge could not measure this page for a full-page screenshot.");
      if (s.width > i.width + 2)
        throw new Error(
          "Horizontal scrolling pages are not supported. Use a selected-area capture."
        );
      be(Math.ceil(s.width * i.dpr), Math.ceil(s.height * i.dpr));
      const u = [], h = Math.max(1, Math.floor(Math.min(i.height, 2048 / i.dpr)));
      if (Math.ceil(s.height / h) > 120)
        throw new Error(
          "This page needs too many full-page sections. Use a selected-area capture."
        );
      let f = 0, E = 0, m = 0, k = 0;
      for (let S = 0; S < s.height; S += h) {
        if (Date.now() - d > 2e4)
          throw new Error("The full-page renderer timed out. Try a smaller capture.");
        const R = Math.min(h, s.height - S);
        let T;
        const F = await Promise.race([
          chrome.debugger.sendCommand(t, "Page.captureScreenshot", {
            format: "png",
            fromSurface: !0,
            captureBeyondViewport: !0,
            clip: { x: s.x, y: s.y + S, width: s.width, height: R, scale: 1 }
          }),
          new Promise((P, K) => {
            T = setTimeout(
              () => K(new Error("The full-page renderer timed out. Try a smaller capture.")),
              Math.max(1, 2e4 - (Date.now() - d))
            );
          })
        ]).finally(() => clearTimeout(T)), p = Zt(F?.data);
        f || (f = p.width / s.width, E = p.width, m = Math.round(s.height * f), be(E, m));
        const g = Math.round(S * f), w = Math.round((S + R) * f);
        if (p.width !== E || Math.abs(p.height - (w - g)) > 1)
          throw new Error("Microsoft Edge returned an incomplete full-page section. Please retry.");
        if (k += p.data.length, k > 48 * 1024 * 1024)
          throw new Error("The full-page image needs too much memory. Try a smaller capture.");
        u.push({ dataUrl: "data:image/png;base64," + p.data, y: g, width: E, height: w - g });
      }
      const L = await a();
      if (!c(s, L)) {
        s = L;
        continue;
      }
      const x = await n();
      return { tiles: u, width: E, height: m, viewport: x };
    }
    throw new Error(
      "The document keeps changing size. Pause live updates or use a visible/selected screenshot."
    );
  } catch (i) {
    const a = i instanceof Error ? i.message : String(i);
    throw /already attached|another debugger|DevTools/i.test(a) ? new Error(
      "Close DevTools or another debugger on this tab, then retry full-page capture."
    ) : new Error(a || "Microsoft Edge could not capture the full page without scrolling.");
  } finally {
    try {
      await r(!0);
    } catch {
    }
    if (o)
      try {
        await chrome.debugger.detach(t);
      } catch {
      }
  }
}
const Ee = "captureflow.capture.v1", tr = "captureflow/capture/v1", v = (e) => !!e && ["starting", "selecting", "capturing"].includes(e.status);
function rr(e) {
  try {
    const t = globalThis.browser ?? globalThis.chrome, o = window;
    o.__captureFlowSelection?.cleanup();
    const r = document.activeElement instanceof HTMLElement ? document.activeElement : null, n = document.createElement("div");
    n.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;";
    const i = n.attachShadow({ mode: "closed" }), a = new CSSStyleSheet();
    a.replaceSync(
      ":host{all:initial}.overlay{position:fixed;inset:0;background:#0008;cursor:crosshair;touch-action:none;user-select:none;font:13px Segoe UI,sans-serif}.selection{position:absolute;display:none;border:2px solid #b6a2ff;box-sizing:border-box;box-shadow:0 0 0 99999px #0008;pointer-events:none}.dimensions{position:absolute;left:0;top:4px;padding:4px 7px;background:#191c22;color:white;white-space:nowrap;border-radius:4px;pointer-events:none}"
    ), i.adoptedStyleSheets = [a];
    const c = document.createElement("div");
    c.className = "overlay", c.tabIndex = 0, c.setAttribute("role", "dialog"), c.setAttribute(
      "aria-label",
      "Drag to capture an area. Release to capture. Escape to cancel."
    );
    const s = document.createElement("div");
    s.className = "selection";
    const d = document.createElement("div");
    d.className = "dimensions", s.append(d), c.append(s), i.append(c), document.documentElement.append(n);
    const l = {
      width: innerWidth,
      height: innerHeight,
      scrollX,
      scrollY,
      dpr: devicePixelRatio
    };
    let u = null, h = { x: 0, y: 0, width: 0, height: 0 }, f = !1, E;
    const m = (p) => p.preventDefault(), k = () => {
      clearTimeout(E), n.remove(), window.removeEventListener("keydown", R, !0), window.removeEventListener("resize", x), window.removeEventListener("scroll", x, !0), window.removeEventListener("wheel", m, !0), window.removeEventListener("touchmove", m, !0), o.__captureFlowSelection?.id === e && delete o.__captureFlowSelection, r?.focus({ preventScroll: !0 });
    }, L = (p) => {
      f || (f = !0, k(), t.runtime.sendMessage({
        channel: "captureflow/capture/v1",
        type: "PAGE_CANCEL",
        id: e,
        ...p ? { error: p } : {}
      }).catch(() => {
      }));
    }, x = () => L("The viewport changed during selection. Please select the area again."), S = async () => {
      if (f || h.width < 2 || h.height < 2) return;
      if (innerWidth !== l.width || innerHeight !== l.height || scrollX !== l.scrollX || scrollY !== l.scrollY || devicePixelRatio !== l.dpr) {
        x();
        return;
      }
      f = !0;
      const p = { ...h };
      k();
      try {
        await new Promise((w, P) => {
          const K = setTimeout(
            () => P(
              new Error(
                "The source page stopped rendering. Keep its tab and window visible, then retry."
              )
            ),
            1e3
          );
          requestAnimationFrame(
            () => requestAnimationFrame(() => {
              clearTimeout(K), w();
            })
          );
        });
        const g = await t.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "SELECTED",
          id: e,
          rect: p,
          viewport: {
            width: innerWidth,
            height: innerHeight,
            documentWidth: document.documentElement.scrollWidth,
            documentHeight: Math.max(document.documentElement.scrollHeight, innerHeight),
            scrollX,
            scrollY,
            dpr: devicePixelRatio,
            visualScale: visualViewport?.scale ?? 1
          }
        });
        if (!g?.ok) throw new Error(g?.error ?? "The selected area could not be captured.");
      } catch (g) {
        t.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: e,
          error: g instanceof Error ? g.message : "The selected area could not be captured."
        }).catch(() => {
        });
      }
    }, R = (p) => {
      p.key === "Escape" ? (p.preventDefault(), p.stopImmediatePropagation(), L()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(p.key) && p.preventDefault();
    }, T = (p, g) => Math.max(0, Math.min(g, p)), F = (p, g) => {
      u && (p = T(p, innerWidth), g = T(g, innerHeight), h = {
        x: Math.min(p, u.x),
        y: Math.min(g, u.y),
        width: Math.abs(p - u.x),
        height: Math.abs(g - u.y)
      }, s.style.display = h.width && h.height ? "block" : "none", Object.assign(s.style, {
        left: h.x + "px",
        top: h.y + "px",
        width: h.width + "px",
        height: h.height + "px"
      }), d.textContent = Math.round(h.width) + " × " + Math.round(h.height) + " px", c.style.background = h.width ? "transparent" : "#0008");
    };
    return c.addEventListener("pointerdown", (p) => {
      p.button !== 0 || f || (p.preventDefault(), c.setPointerCapture(p.pointerId), u = {
        x: T(p.clientX, innerWidth),
        y: T(p.clientY, innerHeight),
        pointerId: p.pointerId
      }, F(p.clientX, p.clientY));
    }), c.addEventListener("pointermove", (p) => {
      u?.pointerId === p.pointerId && F(p.clientX, p.clientY);
    }), c.addEventListener("pointerup", (p) => {
      !u || u.pointerId !== p.pointerId || p.button !== 0 || (F(p.clientX, p.clientY), u = null, S());
    }), c.addEventListener("pointercancel", () => {
      u = null, h = { x: 0, y: 0, width: 0, height: 0 }, s.style.display = "none", c.style.background = "#0008";
    }), window.addEventListener("keydown", R, !0), window.addEventListener("resize", x), window.addEventListener("scroll", x, !0), window.addEventListener("wheel", m, { capture: !0, passive: !1 }), window.addEventListener("touchmove", m, { capture: !0, passive: !1 }), o.__captureFlowSelection = { id: e, cleanup: k }, E = setTimeout(() => L("Selection timed out. Please try again."), 12e4), c.focus({ preventScroll: !0 }), { ok: !0 };
  } catch (t) {
    return {
      ok: !1,
      error: t instanceof Error ? t.message : "Selection is unavailable."
    };
  }
}
let Pe = !1, Ue = !1;
const Le = "captureflow.lastFrameAt";
async function U() {
  return (await chrome.storage.session.get(Ee))[Ee] ?? null;
}
async function D(e) {
  await chrome.storage.session.set({ [Ee]: e });
}
async function ee(e) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#7656c9" }), await chrome.action.setBadgeText({
      text: v(e) ? e.status === "selecting" ? "SEL" : e.progress + "%" : ""
    });
  } catch {
  }
}
async function B(e) {
  const t = await chrome.tabs.get(e.sourceTabId).catch(() => {
    throw new Error("The source tab was closed during capture.");
  });
  if (!t.active || t.windowId !== e.windowId)
    throw new Error("The source tab is no longer active. Keep it selected until capture finishes.");
  if (t.url !== e.sourceUrl)
    throw new Error("The source page navigated during capture. Please try again.");
  return t;
}
async function z(e, t) {
  const r = (await chrome.scripting.executeScript({
    target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
    func: Be,
    args: [t, e.id]
  }))[0]?.result;
  if (!r) throw new Error("The page is no longer available.");
  if (!r.ok) throw new Error(r.error);
  return Ke(r.value), r.value;
}
async function Oe(e) {
  try {
    await z(e, { action: "restore" });
  } catch {
  }
}
async function H(e, t, o) {
  const r = await U();
  if (!r || r.id !== e.id || !v(r)) return;
  const n = { ...r, status: t, message: o, updatedAt: Date.now() };
  await D(n), await ee(n), await Oe(n);
}
async function ce(e) {
  const t = await U();
  if (!t || t.id !== e)
    throw new Error("This capture session has expired. Start a new capture.");
  return t;
}
function J(e, t) {
  return e.id === chrome.runtime.id && e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
async function or(e, t) {
  if (t.id !== chrome.runtime.id) throw new Error("Untrusted capture sender.");
  if (e.type === "GET") {
    if (!J(t, "popup.html") && !J(t, "capture.html"))
      throw new Error("Capture state is private.");
    return U();
  }
  if (e.type === "START") {
    if (!J(t, "popup.html"))
      throw new Error("Start capture from the CaptureFlow popup.");
    if (!["visible", "selected", "full"].includes(e.mode))
      throw new Error("Unknown capture mode.");
    if (Pe) throw new Error("A capture is already starting.");
    Pe = !0;
    let r = null;
    try {
      const n = await U();
      if (v(n)) {
        if (n?.coordinatorTabId !== null ? await chrome.tabs.get(n.coordinatorTabId).then(
          () => !0,
          () => !1
        ) : !1)
          throw new Error("A capture is already running. Cancel it before starting another.");
        n && await H(n, "error", "The capture tab was closed.");
      }
      const i = await Me(t);
      if (i?.id === void 0 || !i.url) throw new Error("No active webpage is available.");
      oe(i.url), me(await fe(), "screenshot");
      const c = (await chrome.scripting.executeScript({
        target: { tabId: i.id },
        func: Be,
        args: [{ action: "inspect" }, "initial"]
      }))[0];
      if (c?.result && !c.result.ok) throw new Error(c.result.error);
      if (!c?.result?.ok || !c.documentId)
        throw new Error("This page cannot be captured. Reload the webpage and try again.");
      Ke(c.result.value);
      const s = e.mode;
      r = {
        id: crypto.randomUUID(),
        mode: s,
        status: "starting",
        sourceTabId: i.id,
        windowId: i.windowId,
        documentId: c.documentId,
        sourceUrl: i.url,
        title: i.title ?? "Screenshot",
        coordinatorTabId: null,
        progress: 0,
        message: "Preparing capture…",
        updatedAt: Date.now()
      }, await D(r);
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("capture.html") + "?id=" + r.id,
        active: !1,
        windowId: i.windowId
      });
      if (d.id === void 0) throw new Error("Could not open the screenshot workspace.");
      return r = { ...r, coordinatorTabId: d.id }, await D(r), await ee(r), r;
    } catch (n) {
      throw r && await H(
        r,
        "error",
        n instanceof Error ? n.message : "Could not start capture."
      ), n;
    } finally {
      Pe = !1;
    }
  }
  const o = await ce(e.id);
  if (e.type === "SELECTED" || e.type === "PAGE_CANCEL") {
    if (t.tab?.id !== o.sourceTabId || t.documentId !== o.documentId)
      throw new Error("The selection came from another page.");
    if (!v(o)) return null;
    if (e.type === "PAGE_CANCEL")
      return await H(
        o,
        e.error ? "error" : "cancelled",
        e.error ?? "Capture cancelled."
      ), null;
    if (o.status !== "selecting" || o.mode !== "selected")
      throw new Error("This session is not selecting an area.");
    ht(e.rect, e.viewport, e.viewport.width, e.viewport.height);
    const r = await z(o, { action: "inspect" });
    if (!tt(e.viewport, r))
      throw new Error("The page moved after selection. Select the area again.");
    return await D({
      ...o,
      selection: { rect: e.rect, viewport: e.viewport },
      status: "capturing",
      message: "Capturing selected area…",
      updatedAt: Date.now()
    }), null;
  }
  if (e.type === "CANCEL") {
    if (!J(t, "popup.html") && t.tab?.id !== o.coordinatorTabId)
      throw new Error("Cannot cancel another capture.");
    return await H(o, "cancelled", "Capture cancelled."), null;
  }
  if (!J(t, "capture.html") || t.tab?.id !== o.coordinatorTabId)
    throw new Error("This request does not belong to the active capture workspace.");
  if (e.type === "PAGE" && e.command.action === "restore")
    return await Oe(o), null;
  if (!v(o)) throw new Error(o.message || "The capture has ended.");
  if (e.type === "FAIL")
    return await H(o, "error", e.error.slice(0, 500)), null;
  if (e.type === "FINISH") {
    await Oe(o);
    const r = await ce(o.id);
    if (!v(r)) throw new Error(r.message);
    const n = {
      ...r,
      status: "complete",
      progress: 100,
      message: "Screenshot ready",
      updatedAt: Date.now()
    };
    return await pt("screenshot", o.id), await D(n), await ee(n), await chrome.tabs.update(o.coordinatorTabId, { active: !0 }), null;
  }
  if (e.type === "PROGRESS") {
    const r = Math.max(0, Math.min(99, Math.round(e.progress)));
    if (!Number.isFinite(r)) throw new Error("Invalid capture progress.");
    const n = {
      ...o,
      status: "capturing",
      progress: r,
      message: e.message.slice(0, 200),
      updatedAt: Date.now()
    };
    return await D(n), await ee(n), null;
  }
  if (e.type === "SELECT") {
    if (o.mode !== "selected" || o.status !== "starting")
      throw new Error("Selection is not available in this session.");
    await B(o), await D({
      ...o,
      status: "selecting",
      message: "Drag to select an area on the webpage.",
      updatedAt: Date.now()
    });
    const n = (await chrome.scripting.executeScript({
      target: { tabId: o.sourceTabId, documentIds: [o.documentId] },
      func: rr,
      args: [o.id]
    }))[0]?.result;
    if (!n) throw new Error("Could not open the selection overlay.");
    if (!n.ok) throw new Error(n.error);
    return await ee({ ...o, status: "selecting" }), null;
  }
  if (e.type === "PAGE") {
    if (!["inspect", "prepare", "step"].includes(e.command.action))
      throw new Error("Unsupported page operation.");
    if (e.command.action === "step" && (!Number.isFinite(e.command.y) || e.command.y < 0))
      throw new Error("Invalid scroll position.");
    return await B(o), z(o, e.command);
  }
  if (e.type === "FULL_PAGE") {
    if (o.mode !== "full")
      throw new Error("Full-page capture is not available in this session.");
    await B(o);
    const r = await er(o);
    await B(o);
    const n = await ce(o.id);
    if (!v(n)) throw new Error(n.message);
    return r;
  }
  if (e.type === "FRAME") {
    if (Ue) throw new Error("Another screenshot frame is being captured.");
    Ue = !0;
    try {
      const r = Number((await chrome.storage.session.get(Le))[Le] ?? 0), n = Math.max(0, 650 - (Date.now() - r));
      n && await new Promise((d) => setTimeout(d, n)), await B(o);
      const i = await z(o, {
        action: o.mode === "full" ? "hideHud" : "inspect"
      });
      await chrome.storage.session.set({ [Le]: Date.now() });
      const a = await chrome.tabs.captureVisibleTab(o.windowId, { format: "png" });
      await B(o);
      const c = await z(o, { action: "inspect" }), s = await ce(o.id);
      if (!v(s)) throw new Error(s.message);
      if (!tt(i, c) || i.documentHeight !== c.documentHeight)
        throw new Error(
          "The page moved or resized during a frame. Please retry once the page is stable."
        );
      return { dataUrl: a, viewport: c };
    } finally {
      if (o.mode === "full")
        try {
          await z(o, { action: "showHud" });
        } catch {
        }
      Ue = !1;
    }
  }
  throw new Error("Unknown capture command.");
}
function nr(e) {
  if (!e || typeof e != "object") throw new Error("Invalid capture message.");
  const t = e;
  if (t.type === "GET") return { type: "GET" };
  if (t.type === "START" && ["visible", "selected", "full"].includes(String(t.mode)))
    return { type: "START", mode: t.mode };
  if (typeof t.id != "string" || t.id.length > 100)
    throw new Error("Invalid capture session.");
  if (["CANCEL", "SELECT", "FRAME", "FULL_PAGE", "FINISH"].includes(String(t.type)))
    return {
      type: t.type,
      id: t.id
    };
  if (t.type === "PAGE" && t.command && typeof t.command == "object") {
    const o = t.command;
    if (["inspect", "prepare", "restore"].includes(String(o.action)))
      return {
        type: "PAGE",
        id: t.id,
        command: { action: o.action }
      };
    if (o.action === "step" && typeof o.y == "number" && Number.isFinite(o.y) && typeof o.progress == "number" && Number.isFinite(o.progress) && typeof o.hideSticky == "boolean")
      return {
        type: "PAGE",
        id: t.id,
        command: {
          action: "step",
          y: o.y,
          progress: o.progress,
          hideSticky: o.hideSticky
        }
      };
  }
  if (t.type === "PROGRESS" && typeof t.progress == "number" && typeof t.message == "string")
    return { type: "PROGRESS", id: t.id, progress: t.progress, message: t.message };
  if (t.type === "FAIL" && typeof t.error == "string")
    return { type: "FAIL", id: t.id, error: t.error };
  if (t.type === "PAGE_CANCEL" && (t.error === void 0 || typeof t.error == "string"))
    return {
      type: "PAGE_CANCEL",
      id: t.id,
      ...typeof t.error == "string" ? { error: t.error } : {}
    };
  if (t.type === "SELECTED") {
    const o = t.rect, r = t.viewport;
    return ht(o, r, r?.width, r?.height), { type: "SELECTED", id: t.id, rect: o, viewport: r };
  }
  throw new Error("Unsupported capture message.");
}
async function ir(e) {
  const t = await U();
  t && (t.coordinatorTabId === e ? (v(t) && await H(t, "cancelled", "The capture workspace was closed."), (await U())?.id === t.id && await chrome.storage.session.remove(Ee)) : t.sourceTabId === e && v(t) && await H(t, "error", "The source tab was closed during capture."));
}
async function q() {
  return (await chrome.storage.session.get(_e))[_e] ?? null;
}
async function wt(e) {
  if (e && ["starting", "recording", "paused", "stopping"].includes(e.status))
    await chrome.action.setBadgeBackgroundColor({
      color: e.status === "paused" ? "#a16207" : "#dc2626"
    }), await chrome.action.setBadgeText({
      text: e.status === "paused" ? "Ⅱ" : e.status === "recording" ? "REC" : "…"
    });
  else {
    const t = await U();
    v(t) || await chrome.action.setBadgeText({ text: "" });
  }
}
async function y(e) {
  return await chrome.storage.session.set({ [_e]: e }), await wt(e), e;
}
function O(e, t) {
  return e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
function ar(e) {
  if (e.id !== chrome.runtime.id || !["popup.html", "recording.html", "offscreen.html", "controls.html"].some(
    (t) => O(e, t)
  ))
    throw new Error("Untrusted recording request.");
}
function rt(e, t) {
  return t.owner === "offscreen" ? O(e, "offscreen.html") && e.tab === void 0 : O(e, "recording.html") && e.tab?.id === t.controllerTabId;
}
async function cr(e) {
  const t = await q();
  if (!t || t.id !== e)
    throw new Error("This recording session has expired. Open a new recorder.");
  return t;
}
async function We(e) {
  if (e.owner === "offscreen")
    return (await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL("offscreen.html")]
    })).length > 0;
  if (e.controllerTabId === null) return !1;
  try {
    return (await chrome.runtime.getContexts({
      contextTypes: ["TAB"],
      tabIds: [e.controllerTabId],
      documentUrls: [chrome.runtime.getURL("recording.html?id=" + e.id)]
    })).length > 0;
  } catch {
    return !1;
  }
}
async function j(e, t, o = {}) {
  const r = await chrome.runtime.sendMessage({
    channel: Qt,
    target: e.owner === "offscreen" ? "offscreen" : "page:" + e.id,
    type: t,
    id: e.id,
    ...o
  });
  if (!r?.ok)
    throw new Error(
      r?.error ?? "The recording host is unavailable. Open the recorder to recover saved chunks."
    );
  return r.data;
}
async function ft(e = "tab") {
  if ((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL("offscreen.html")]
  })).length) {
    if (e === "tab") return;
    await chrome.offscreen.closeDocument();
  }
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: e === "tab" ? ["USER_MEDIA"] : ["USER_MEDIA", "DISPLAY_MEDIA"],
    justification: "Record the explicitly requested tab, window or screen and audio while the popup is closed."
  });
}
async function ot(e) {
  const t = await chrome.tabs.create({
    url: chrome.runtime.getURL("recording.html?preview=" + encodeURIComponent(e)),
    active: !0
  });
  t.id !== void 0 && await Vt(e, t.id);
}
async function ve(e, t) {
  let o = await ye(e.id);
  if (o) {
    o = {
      ...o,
      bytes: (await Gt(e.id, o.mimeType)).size,
      warning: o.complete ? o.warning : t + " Only previously committed chunks may be recoverable."
    };
    try {
      await Bt(o);
    } catch {
    }
  }
  return y({
    ...e,
    status: o?.bytes ? "complete" : "error",
    elapsedMs: o?.durationMs ?? Xt(e),
    clockStartedAt: null,
    error: o?.bytes ? "" : t,
    warning: o?.bytes ? t : e.warning
  });
}
async function sr(e, t) {
  if (ar(t), !e || typeof e != "object") throw new Error("Invalid recorder request.");
  const o = e;
  if (o.type === "GET") return Se();
  if (o.type === "START_POPUP") {
    if (!O(t, "popup.html"))
      throw new Error("Start recording from the CaptureFlow popup.");
    const n = Ie(xe(o.options)), i = await Se();
    if (A(i))
      throw new Error("A recording is already active. Stop or cancel it before starting another.");
    if (me(await fe(), "video"), v(await U())) throw new Error("Finish the screenshot before recording.");
    const a = await Me(t);
    if (n.mode === "tab") {
      if (a?.id === void 0 || !a.url) throw new Error("Select a webpage before recording.");
      oe(a.url);
    }
    const c = await $e(), s = {
      id: crypto.randomUUID(),
      options: n,
      popupStart: !0,
      owner: "offscreen",
      controllerTabId: null,
      sourceTabId: a?.id ?? null,
      title: n.mode === "tab" ? a?.title ?? "Tab recording" : n.mode === "window" ? "Window recording" : "Screen recording",
      sourceUrl: n.mode === "tab" ? a?.url ?? "" : "",
      createdAt: Date.now(),
      status: "starting",
      elapsedMs: 0,
      clockStartedAt: null,
      hasMicrophone: !1,
      microphone: !1,
      hasAudio: !1,
      audio: !1,
      bytes: 0,
      warning: "",
      error: "",
      retention: c.autoSave ? "saved" : "temporary"
    };
    return await y(s), ur(s);
  }
  if (o.type === "PREPARE") {
    if (!O(t, "popup.html"))
      throw new Error("Open the recorder from the extension popup.");
    const n = Ie(xe(o.options)), i = await q();
    if (A(i))
      if (i?.controllerTabId !== null && i?.controllerTabId !== void 0)
        try {
          return await chrome.tabs.update(i.controllerTabId, { active: !0 }), i;
        } catch {
          if (i.status !== "setup" && await We(i)) return i;
          await ve(i, "The recorder page was closed.");
        }
      else throw new Error("Another recording is starting.");
    if (v(await U()))
      throw new Error("Finish the screenshot capture before starting a recording.");
    const a = await Me(t);
    if (n.mode === "tab") {
      if (a?.id === void 0 || !a.url)
        throw new Error("Select a webpage before recording a tab.");
      oe(a.url);
    }
    const c = crypto.randomUUID(), s = {
      id: c,
      options: n,
      owner: n.mode === "tab" ? "offscreen" : "page",
      controllerTabId: null,
      sourceTabId: a?.id ?? null,
      title: n.mode === "tab" ? a?.title ?? "Tab recording" : n.mode === "window" ? "Window recording" : "Screen recording",
      sourceUrl: n.mode === "tab" ? a?.url ?? "" : "",
      createdAt: Date.now(),
      status: "setup",
      elapsedMs: 0,
      clockStartedAt: null,
      hasMicrophone: !1,
      microphone: !1,
      hasAudio: !1,
      audio: !1,
      bytes: 0,
      warning: "",
      error: ""
    };
    await y(s);
    try {
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("recording.html?id=" + c),
        active: !0
      });
      if (d.id === void 0) throw new Error("Microsoft Edge could not open the recorder.");
      return y({ ...s, controllerTabId: d.id });
    } catch (d) {
      throw await y({ ...s, status: "error", error: "Microsoft Edge could not open the recorder." }), d;
    }
  }
  if (o.type === "OPEN_PREVIEW") {
    if (typeof o.id != "string" || !await ye(o.id))
      throw new Error("This saved recording is unavailable.");
    return await ot(o.id), null;
  }
  const r = await cr(o.id);
  if (o.type === "OPEN" && r.popupStart && A(r))
    return y(await Xe(r));
  if (o.type === "OPEN") {
    if (r.controllerTabId !== null)
      try {
        return await chrome.tabs.update(r.controllerTabId, { active: !0 }), r;
      } catch {
      }
    const n = await chrome.tabs.create({
      url: chrome.runtime.getURL("recording.html?id=" + r.id),
      active: !0
    });
    return y({ ...r, controllerTabId: n.id ?? null });
  }
  if (o.type === "BEGIN") {
    if (!O(t, "recording.html") || t.tab?.id !== r.controllerTabId || !["setup", "error"].includes(r.status))
      throw new Error("This recording cannot start from this page or state.");
    if (v(await U())) throw new Error("Finish the screenshot before recording.");
    me(await fe(), "video", r.id);
    const n = Ie(xe(o.options));
    if (n.mode !== r.options.mode)
      throw new Error("Open a new recorder to change source mode.");
    const i = await $e(), a = {
      ...r,
      options: n,
      retention: i.autoSave ? "saved" : "temporary",
      status: "starting",
      error: "",
      warning: ""
    };
    if (await y(a), n.mode === "tab")
      try {
        if (r.sourceTabId === null) throw new Error("The source tab is unavailable.");
        const c = await chrome.tabs.get(r.sourceTabId);
        oe(c.url ?? ""), await ft();
        const s = await chrome.tabCapture.getMediaStreamId({
          targetTabId: r.sourceTabId
        });
        await j(a, "START_TAB", { streamId: s, session: a });
      } catch (c) {
        await y({
          ...a,
          status: "error",
          error: c instanceof Error ? c.message : "Tab capture failed."
        });
        try {
          await chrome.offscreen.closeDocument();
        } catch {
        }
        throw c;
      }
    return a;
  }
  if (o.type === "UPDATE") {
    if (!rt(t, r))
      throw new Error("Only the current recording host may publish state.");
    if (!A(r)) return r;
    const n = o.snapshot;
    if (!n || !["starting", "recording", "paused", "stopping", "complete", "error"].includes(
      String(n.status)
    ) || !Number.isFinite(n.elapsedMs) || !Number.isFinite(n.bytes) || n.elapsedMs < 0 || n.bytes < 0 || !(n.clockStartedAt === null || Number.isFinite(n.clockStartedAt)) || !["audio", "hasAudio", "microphone", "hasMicrophone"].every(
      (a) => typeof n[a] == "boolean"
    ) || typeof n.warning != "string")
      throw new Error("Invalid recording state.");
    if (n.status === "recording" && r.status === "starting")
      try {
        await pt("video", r.id);
      } catch (a) {
        throw await j(r, "STOP", { reason: "Monthly usage could not be saved." }).catch(
          () => {
          }
        ), a;
      }
    let i = await y({
      ...r,
      status: n.status === "complete" ? "stopping" : n.status,
      elapsedMs: n.elapsedMs,
      clockStartedAt: n.clockStartedAt,
      bytes: n.bytes,
      microphone: !1,
      hasMicrophone: !1,
      audio: n.audio,
      hasAudio: n.hasAudio,
      warning: n.warning,
      error: n.status === "error" ? n.warning : ""
    });
    if (r.popupStart && n.status === "recording" && !r.controlsOpened)
      try {
        i = await y(await Xe(i, !0));
      } catch (a) {
        i = await y({
          ...i,
          controlsOpened: !0,
          controlsError: a instanceof Error ? a.message : "Open recording controls from the extension popup."
        });
      }
    return n.status === "error" && await Ce(r), n.status === "error" && r.owner === "offscreen" && await chrome.offscreen.closeDocument(), i;
  }
  if (o.type === "COMPLETE") {
    if (!rt(t, r)) throw new Error("Only the current host may finish recording.");
    const n = await ye(r.id);
    if (!n) throw new Error("The recording could not be saved locally.");
    const i = await y({
      ...r,
      status: n.bytes ? "complete" : "error",
      elapsedMs: n.durationMs,
      clockStartedAt: null,
      bytes: n.bytes,
      warning: n.warning,
      error: n.bytes ? "" : "No video data was saved."
    });
    try {
      await Ce(r), n.bytes && await ot(r.id);
    } finally {
      le(), r.owner === "offscreen" && await chrome.offscreen.closeDocument();
    }
    return i;
  }
  if (o.type === "FAIL") {
    if (!O(t, "recording.html") || t.tab?.id !== r.controllerTabId)
      throw new Error("Untrusted recording failure.");
    if (!["setup", "starting", "error"].includes(r.status))
      throw new Error("The recording is already running.");
    return y({
      ...r,
      status: "error",
      clockStartedAt: null,
      error: typeof o.error == "string" ? o.error : "Recording start failed."
    });
  }
  if (o.type === "CANCEL_SETUP") {
    if (!["setup", "error"].includes(r.status))
      throw new Error("Stop the active recording first.");
    return y({ ...r, status: "cancelled", error: "" });
  }
  if (["PIN_CONTROLS", "UNPIN_CONTROLS", "CLOSE_CONTROLS"].includes(String(o.type))) {
    if (!O(t, "controls.html") || t.tab?.id !== r.controlsTabId || r.controlsWindowId == null)
      throw new Error("Only this recording controls window may change its visibility.");
    return o.type === "PIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, { state: "minimized" }) : o.type === "UNPIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, {
      state: "normal",
      focused: !0,
      width: 280,
      height: 106
    }) : await Ce(r), null;
  }
  if (o.type === "CONTROL") {
    if (!["PAUSE", "RESUME", "STOP", "AUDIO"].includes(String(o.command)))
      throw new Error("Unknown recording control.");
    if (!A(r) || r.status === "setup")
      throw new Error("No active recording is available.");
    if (o.command === "AUDIO" && typeof o.enabled != "boolean")
      throw new Error("Invalid audio toggle.");
    return j(r, String(o.command), { enabled: o.enabled === !0 });
  }
  throw new Error("Unknown recording request.");
}
async function lr(e) {
  const t = await q();
  if (!(!t || !A(t))) {
    if (t.controlsTabId === e) {
      await y({ ...t, controlsWindowId: null, controlsTabId: null });
      return;
    }
    if (t.sourceTabId === e && t.options.mode === "tab" && t.status !== "setup")
      try {
        await j(t, "STOP", { reason: "The source tab closed." });
      } catch {
        await ve(t, "The source tab closed.");
      }
    else if (t.controllerTabId === e) {
      if (t.owner === "offscreen" && t.status !== "setup" && await We(t)) {
        await y({ ...t, controllerTabId: null });
        return;
      }
      await ve(t, "The recorder tab closed.");
    }
  }
}
async function Se() {
  let e = await q();
  if (e && A(e) && e.status !== "setup") {
    let t = !await We(e);
    if (!t && ["recording", "paused", "stopping"].includes(e.status))
      try {
        await j(e, "PING");
      } catch {
        t = !0;
      }
    t && (e = await ve(e, "The recording host closed or was interrupted."));
  }
  return e;
}
async function ur(e) {
  try {
    if (await ft(e.options.mode), e.options.mode === "tab") {
      if (e.sourceTabId === null) throw new Error("The source tab is unavailable.");
      const t = await chrome.tabs.get(e.sourceTabId);
      oe(t.url ?? "");
      const o = await chrome.tabCapture.getMediaStreamId({
        targetTabId: e.sourceTabId
      });
      await j(e, "START_TAB", { streamId: o, session: e });
    } else await j(e, "START_DISPLAY", { session: e });
    return e;
  } catch (t) {
    await y({
      ...e,
      status: "error",
      clockStartedAt: null,
      error: t instanceof Error ? t.message : "Recording could not start."
    });
    try {
      await chrome.offscreen.closeDocument();
    } catch {
    }
    throw t;
  }
}
function dr() {
  return chrome.runtime.getContexts({ contextTypes: ["TAB"] });
}
async function pr(e = null) {
  return C(["screenshots", "recordings"], "readonly", (t, o) => {
    const r = t.objectStore("screenshots").getAll(), n = t.objectStore("recordings").getAll();
    let i = 0;
    const a = () => {
      if (++i !== 2) return;
      const c = [
        ...r.result,
        ...n.result.filter((s) => s.id !== e && s.bytes > 0 && s.retention !== "temporary").map((s) => ({
          id: s.id,
          kind: "recording",
          title: s.title,
          sourceUrl: s.sourceUrl ?? "",
          createdAt: s.createdAt,
          updatedAt: s.createdAt,
          bytes: s.bytes,
          durationMs: s.durationMs,
          complete: s.complete,
          warning: s.warning
        }))
      ];
      o(c.sort((s, d) => d.createdAt - s.createdAt || s.id.localeCompare(d.id)));
    };
    r.onsuccess = a, n.onsuccess = a;
  });
}
async function hr(e, t, o = null) {
  if (e === "recording" && t === o)
    throw new Error("Stop the active recording before deleting it.");
  await C(["screenshots", "recordings", "chunks", "assets"], "readwrite", (r) => {
    r.objectStore(e === "screenshot" ? "screenshots" : "recordings").delete(t), e === "recording" && je(r, t), ge(r, t);
  });
}
async function wr(e = null) {
  return C(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      let r = 0, n = 2;
      const i = t.objectStore("screenshots").openCursor(), a = t.objectStore("recordings").openCursor();
      i.onsuccess = () => {
        const c = i.result;
        if (!c) {
          --n || o(r);
          return;
        }
        ge(t, String(c.primaryKey)), c.delete(), r++, c.continue();
      }, a.onsuccess = () => {
        const c = a.result;
        if (!c) {
          --n || o(r);
          return;
        }
        const s = c.value;
        s.id !== e && s.retention !== "temporary" && (je(t, s.id), ge(t, s.id), c.delete(), r++), c.continue();
      };
    }
  );
}
async function fr(e = null) {
  return C(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      const r = t.objectStore("screenshots").getAllKeys(), n = t.objectStore("recordings").getAllKeys();
      let i = 2;
      const a = () => {
        if (--i) return;
        const c = new Set([...r.result, ...n.result].map(String));
        e && c.add(e);
        let s = 0, d = 2;
        for (const l of ["chunks", "assets"]) {
          const u = t.objectStore(l).openKeyCursor();
          u.onsuccess = () => {
            const h = u.result;
            if (!h) {
              --d || o(s);
              return;
            }
            const f = h.primaryKey;
            c.has(f[0]) || (t.objectStore(l).delete(h.primaryKey), s++), h.continue();
          };
        }
      };
      r.onsuccess = a, n.onsuccess = a;
    }
  );
}
async function ie(e = !1, t) {
  const o = t === void 0 ? await Se() : null, r = t === void 0 ? A(o) ? o.id : null : t, n = new Set(r ? [r] : []);
  if (!e && (await Wt()).some((i) => i.retention === "temporary")) {
    for (const i of await dr())
      if (i.documentUrl)
        try {
          const a = new URL(i.documentUrl);
          if (a.protocol !== new URL(chrome.runtime.getURL("")).protocol || a.host !== new URL(chrome.runtime.getURL("")).host || a.pathname !== "/recording.html")
            continue;
          const c = a.searchParams.get("preview");
          c && n.add(c);
        } catch {
        }
  }
  return await Yt(n), await fr(r ?? null), r ?? null;
}
async function mr(e, t) {
  if (t.id !== chrome.runtime.id || !["popup.html", "capture.html", "recording.html", "history.html"].some(
    (i) => t.url?.split("?")[0] === chrome.runtime.getURL(i)
  ))
    throw new Error("History is private to CaptureFlow pages.");
  if (!e || typeof e != "object") throw new Error("Invalid history request.");
  const o = e, r = await Se(), n = A(r) ? r.id : null;
  if (o.type === "LIST")
    return await ie(!1, n), { items: await pr(n), activeRecordingId: n };
  if (o.type === "DELETE") {
    if (!["screenshot", "recording"].includes(String(o.kind)) || typeof o.id != "string" || !o.id)
      throw new Error("Invalid history item.");
    await hr(o.kind, o.id, n);
  } else if (o.type === "CLEAR") {
    const i = await wr(n);
    return await ie(!1, n), le(), i;
  } else if (o.type === "KEEP_RECORDING") {
    if (typeof o.id != "string" || o.id === n)
      throw new Error("Finish recording before keeping it in history.");
    if (!(await ye(o.id))?.bytes) throw new Error("This recording is unavailable.");
    const a = await zt(o.id);
    return le(), a;
  } else throw new Error("Unknown history request.");
  return le(), null;
}
const mt = "captureflow/v1";
function gr(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.channel === mt && t.type === "GET_APP_INFO";
}
function yr(e, t, o, r) {
  return t !== o ? { ok: !1, error: "Untrusted message sender." } : gr(e) ? {
    ok: !0,
    data: {
      version: r,
      phase: 6,
      capabilities: [
        "preferences",
        "themes",
        "navigation",
        "screenshots",
        "annotations",
        "recording",
        "history"
      ]
    }
  } : { ok: !1, error: "Unsupported CaptureFlow message." };
}
function $(e) {
  const t = e instanceof Error ? e.message : "An unexpected error occurred.";
  return /quota|QUOTA_BYTES/i.test(t) ? "Local storage is full. Free some space and try again." : /receiving end|connection|message port|timed out/i.test(t) ? "Cannot reach CaptureFlow. Reload the extension in your browser’s extension manager and try again." : t;
}
function Ge() {
  let e = Promise.resolve();
  return (t) => {
    const o = e.then(t);
    return e = o.then(
      () => {
      },
      () => {
      }
    ), o;
  };
}
const Q = Ge(), gt = Q, De = Ge(), br = Ge();
chrome.runtime.onMessage.addListener((e, t, o) => e && typeof e == "object" && "channel" in e && e.channel === St ? !("type" in e) || e.type !== "OPEN" ? (o({ ok: !1, error: "Unknown window request." }), !1) : (br(() => Et(t)).then(
  () => o({ ok: !0 }),
  (r) => o({ ok: !1, error: $(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Pt ? (("type" in e && e.type === "STATUS" ? qe(e, t) : De(() => qe(e, t))).then(
  (n) => o({ ok: !0, data: n }),
  (n) => o({ ok: !1, error: $(n) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Nt ? (De(() => Ft(e, t)).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: $(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === _t ? (Q(async () => (await I(), mr(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: Ot(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === qt ? (gt(async () => (await I(), sr(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: $(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === tr ? (Q(async () => {
  await I();
  const r = nr(e);
  if (r.type === "START" && A(await q()))
    throw new Error("Finish or cancel the recorder before capturing screenshots.");
  const n = await or(r, t), i = await q();
  return A(i) && await wt(i), n;
}).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: $(r) })
), !0) : (!e || typeof e != "object" || !("channel" in e) || e.channel !== mt || o(
  yr(e, t.id, chrome.runtime.id, chrome.runtime.getManifest().version)
), !1));
chrome.tabs.onRemoved.addListener((e) => {
  gt(async () => {
    await lr(e), await ie();
  }).catch(console.error), Q(() => ir(e)).catch(console.error);
});
chrome.runtime.onStartup?.addListener(() => {
  Q(() => ie(!0)).catch(console.error);
});
chrome.runtime.onInstalled?.addListener(() => {
  chrome.storage.local.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" }), Q(() => ie(!0)).catch(console.error);
});
chrome.windows?.onFocusChanged?.addListener((e) => {
  vt(e).catch(() => {
  });
});
X() && chrome.permissions.onRemoved.addListener((e) => {
  ((e.data_collection ?? []).some((o) => nt.includes(o)) || e.origins?.some((o) => o.startsWith("https://captureflow-billing."))) && De(() => V(!1)).catch(() => {
  });
});
