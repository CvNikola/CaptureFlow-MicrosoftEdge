import"./entitlement-CEtrZu2c.js";import{c as o}from"./host-CBp5F8DH.js";import"./recording-eFgCIUIU.js";import"./recordings-z3P68Jnv.js";import"./recordingMessaging-iEcan3kW.js";o("offscreen");
